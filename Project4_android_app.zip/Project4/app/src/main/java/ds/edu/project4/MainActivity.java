//citation:chatgpt
//Zheyu Yan
//zheyuyan
package ds.edu.project4;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private EditText tickerInput, dateInput;
    private Button fetchButton;
    private TextView resultView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        tickerInput = findViewById(R.id.tickerInput);
        dateInput = findViewById(R.id.dateInput);
        fetchButton = findViewById(R.id.fetchButton);
        resultView = findViewById(R.id.resultView);

        // Set button click listener
        fetchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ticker = tickerInput.getText().toString().trim();
                String date = dateInput.getText().toString().trim();

                if (ticker.isEmpty() || date.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both ticker and date", Toast.LENGTH_SHORT).show();
                } else {
                    fetchStockData(ticker, date);
                }
            }
        });
    }

    private void fetchStockData(String ticker, String date) {
        //String urlString = "http://100.110.161.104:8080/Project4Task2_war_exploded/stockdata?ticker=" + ticker + "&date=" + date;
        String urlString = "https://silver-space-fortnight-j76qjgvgqg42q6q9-8080.app.github.dev/stockdata?ticker=" + ticker + "&date=" + date;
        Log.d("API_URL", urlString); // Log the API URL

        // Create a request queue
        RequestQueue queue = Volley.newRequestQueue(this);

        // Make a GET request
        StringRequest stringRequest = new StringRequest(Request.Method.GET, urlString,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("Server Response", response); // Log the response
                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            // Parse only the fields present in the response
                            double open = jsonObject.optDouble("open", -1); // Default to -1 if missing
                            double close = jsonObject.optDouble("close", -1);
                            double high = jsonObject.optDouble("high", -1);
                            double low = jsonObject.optDouble("low", -1);

                            // Display the results
                            String resultText = String.format(
                                    "Date: %s\nTicker: %s\nOpen: %.2f\nClose: %.2f\nHigh: %.2f\nLow: %.2f",
                                    jsonObject.optString("date", "N/A"),
                                    jsonObject.optString("ticker", "N/A"),
                                    open, close, high, low
                            );

                            resultView.setText(resultText);

                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(MainActivity.this, "Error parsing data", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = "Failed to fetch data";
                        if (error.networkResponse != null) {
                            int statusCode = error.networkResponse.statusCode;
                            String errorBody = new String(error.networkResponse.data);
                            message += ": HTTP Status Code " + statusCode + "\nResponse: " + errorBody;
                            Log.e("API Error", "Status Code: " + statusCode + ", Response: " + errorBody);
                        } else {
                            message += ": No network response";
                        }
                        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                        error.printStackTrace();
                    }
                });

        // Add timeout policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                5000, // Timeout in milliseconds
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        // Add the request to the queue
        queue.add(stringRequest);
    }
}
